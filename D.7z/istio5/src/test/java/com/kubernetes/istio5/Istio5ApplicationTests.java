package com.kubernetes.istio5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Istio5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
