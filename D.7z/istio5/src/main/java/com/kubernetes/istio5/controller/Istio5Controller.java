package com.kubernetes.istio5.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kubernetes.istio5.service.Istio5Service;

@RestController
@RequestMapping("/v1/api")
public class Istio5Controller {

	@Autowired
	Istio5Service istioService;

	@GetMapping("/service5")
	public String service5() {
		System.out.println("Service5 is up and running!");
		return "Service5 calls Service4!" + "\n" + istioService.callService5();
	}

}
