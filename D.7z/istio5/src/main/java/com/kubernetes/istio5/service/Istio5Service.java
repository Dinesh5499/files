package com.kubernetes.istio5.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class Istio5Service {

	@Autowired
	public RestTemplate restTemplate;

	public String callService5() {
		String fooResourceUrl = "http://myapp4-service:8080/v1/api";
		ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl + "/service4", String.class);
		return response.getBody();
	}
}
