package com.kubernetes.istio5.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class IstioConfig5 {
	
	
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}

}
