package com.kubernetes.istio5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Istio5Application {

	public static void main(String[] args) {
		SpringApplication.run(Istio5Application.class, args);
	}

}
