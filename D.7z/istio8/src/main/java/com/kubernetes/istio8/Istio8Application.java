package com.kubernetes.istio8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Istio8Application {

	public static void main(String[] args) {
		SpringApplication.run(Istio8Application.class, args);
	}

}
