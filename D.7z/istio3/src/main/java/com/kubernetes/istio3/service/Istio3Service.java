package com.kubernetes.istio3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

public class Istio3Service {

	@Autowired
	public RestTemplate restTemplate;
	
	public String callService3() {		
		return "service3 is up and running";
	}

}
