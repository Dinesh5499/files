package com.kubernetes.istio3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Istio3Application {

	public static void main(String[] args) {
		SpringApplication.run(Istio3Application.class, args);
	}

}
