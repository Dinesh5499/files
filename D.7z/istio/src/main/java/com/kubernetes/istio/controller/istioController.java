package com.kubernetes.istio.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kubernetes.istio.service.IstioService;

@RestController
@RequestMapping("/v1/api")
public class istioController {

	@Autowired
	IstioService istioService;

	@GetMapping("/service")
	public String service() {
		System.out.println("Service service is up and running!");
		return "Service calls Service1!" + "\n" + istioService.callService();

	}

	@GetMapping("/service2")
	public String service2() {
		System.out.println("Service service2 is up and running!");
		return "Service calls Service1!" + "\n" + istioService.callService2();

	}

}
