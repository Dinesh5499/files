package com.kubernetes.istio.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class IstioService {

	@Autowired
	public RestTemplate restTemplate;

	public String callService() {
		String fooResourceUrl = "http://myapp1-service:8080/v1/api";
		ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl + "/service1", String.class);
		return response.getBody();
	}

	public String callService2() {
		String fooResourceUrl = "http://myapp2-service:8080/v1/api";
		ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl + "/service2", String.class);
		return response.getBody();
	}

}
