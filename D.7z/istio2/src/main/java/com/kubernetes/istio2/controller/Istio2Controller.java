package com.kubernetes.istio2.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kubernetes.istio2.service.Istio2Service;


@RestController
@RequestMapping("/v1/api")
public class Istio2Controller {

	@Autowired
	Istio2Service istioService;

	@GetMapping("/service2")
	public String service2() {
		System.out.println("Service2 is up and running!");
		return "Service2 calls Service5!"+ "\n" + istioService.callService();
	}

}
