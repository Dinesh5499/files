package com.kubernetes.istio2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class Istio2Service {

	@Autowired
	public RestTemplate restTemplate;

	public String callService() {
		String fooResourceUrl = "http://myapp5-service.nspace2:8080/v1/api";
		ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl + "/service5", String.class);
		return response.getBody();

	}
}