package com.kubernetes.istio2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Istio2Application {

	public static void main(String[] args) {
		SpringApplication.run(Istio2Application.class, args);
	}

}
