package com.kubernetes.istio2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Istio2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
