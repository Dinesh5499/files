package com.kubernetes.istio6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Istio6Application {

	public static void main(String[] args) {
		SpringApplication.run(Istio6Application.class, args);
	}

}
