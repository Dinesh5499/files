package com.kubernetes.istio6.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

public class Istio6Service {

	@Autowired
	public RestTemplate restTemplate;
	
	public String callService6() {		
		return "service6 is up and running";
	}

}
