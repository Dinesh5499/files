package com.kubernetes.istio6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Istio6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
