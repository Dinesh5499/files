package com.kubernetes.istio1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class Istio1Service {

	@Autowired
	public RestTemplate restTemplate1;
	
	public String callService1() {		
		String fooResourceUrl
		  = "http://myapp3-service.nspace2:8080/v1/api";
		ResponseEntity<String> response
		  = restTemplate1.getForEntity(fooResourceUrl + "/service3", String.class);
		return response.getBody();

	}

}
