package com.kubernetes.istio1.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kubernetes.istio1.service.Istio1Service;

@RestController
@RequestMapping("/v1/api")
public class Istio1Controller {

	@Autowired
	Istio1Service istio1Service;

	@GetMapping("/service1")
	public String service1() {
		System.out.println("Service1 service is up and running!");
		return "Service1 is up and running!"+ "\n" + istio1Service.callService1();
	}

}
