package com.kubernetes.istio4.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class Istio4Service {

	@Autowired
	public RestTemplate restTemplate;
	
	public String callService() {		
		//String fooResourceUrl = "http://myapp7-service.nspace2:8080/v1/api";
		//ResponseEntity<String> response = restTemplate.getForEntity(fooResourceUrl + "/service7", String.class);
		//return response.getBody();
		return "test";
	}

}
