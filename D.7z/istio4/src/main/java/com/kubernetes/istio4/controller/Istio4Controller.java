package com.kubernetes.istio4.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kubernetes.istio4.service.Istio4Service;


@RestController
@RequestMapping("/v1/api")
public class Istio4Controller {
	
	@Autowired
	Istio4Service istioService;

	@GetMapping("/service4")
	public String service4() {
		System.out.println("Service4 is up and running!");
		return "Service4 is up and running!"+ "\n" + istioService.callService();
	}

}
